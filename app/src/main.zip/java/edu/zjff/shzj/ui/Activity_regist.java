package edu.zjff.shzj.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import edu.zjff.shzj.R;
import edu.zjff.shzj.entity.User;
import edu.zjff.shzj.service.RegistService;
import edu.zjff.shzj.service.RequestYZMService;
import edu.zjff.shzj.util.Constant;
import edu.zjff.shzj.util.ToastUtils;

public class Activity_regist extends AppCompatActivity {
    TextView tv_reg;private MyReceiver receiver;private Intent service;private IntentFilter intentFilter;
    EditText et_count,et_pwd,et_yzm,et_phone,et_email;
    ImageView iv_yzm;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.regist);
        tv_reg=findViewById(R.id.tv_reg);
        et_count=findViewById(R.id.et_count);et_pwd=findViewById(R.id.et_pwd);et_yzm=findViewById(R.id.et_yzm);
        et_phone=findViewById(R.id.et_phone);et_email=findViewById(R.id.et_email);iv_yzm=findViewById(R.id.iv_yzm);
        startServiceToGetYZM();
        iv_yzm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startServiceToGetYZM();
            }
        });
        tv_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO 最好检测非空
                    User user = new User();
                    user.setUsername(et_count.getText()+"");
                    user.setPassword(et_pwd.getText()+"");
                    user.setPhone(et_phone.getText()+"");
                    user.setEmail(et_email.getText()+"");
                    user.setCaptcha(et_yzm.getText()+"");
                    startService(user);
                ToastUtils.showToast(Activity_regist.this,"请求已经递交请等待",0);
            }
        });
        registerReceiver();
    }

    private void registerReceiver() {
        intentFilter=new IntentFilter();
        intentFilter.addAction(Constant.BROADCAST_REG_WRONG);
        intentFilter.addAction(Constant.BROADCAST_REG_SUCCESS);
        intentFilter.addAction(Constant.BROADCAST_YZM_WRONG);
        intentFilter.addAction(Constant.BROADCAST_YZM_SUCCESS);
        receiver=new MyReceiver();
        registerReceiver(receiver,intentFilter);
    }
    private void startService(User user){
        service=new Intent(this, RegistService.class);
        service.putExtra(Constant.USER,user);
        startService(service);
    }
    private void startServiceToGetYZM(){
        service=new Intent(this, RequestYZMService.class);
        startService(service);
    }

    @Override
    protected void onDestroy(){
        //窗口销毁时,启动的service需要停止
        if(service!=null){
            stopService(service);
        }
        unregisterReceiver(receiver);//动态注册的广播接收器需取消
        super.onDestroy();
    }
    class MyReceiver extends BroadcastReceiver {
        //该方法运行在主线程
        @Override
        public void onReceive(Context context, final Intent intent) {
            switch (intent.getAction()){
                case Constant.BROADCAST_REG_SUCCESS:
                    break;
                case Constant.BROADCAST_REG_WRONG:
                    ToastUtils.showToast(Activity_regist.this,"注册失败",0);
                    break;
                case Constant.BROADCAST_YZM_SUCCESS:

                     final Bitmap bm = intent.getParcelableExtra(Constant.YZM);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            iv_yzm.setImageBitmap(bm);
                        }
                    });
                    ToastUtils.showToast(Activity_regist.this,"获取验证码成功",0);
                    break;
                case Constant.BROADCAST_YZM_WRONG:
                    ToastUtils.showToast(Activity_regist.this,"他娘的服务器炸了",0);
                    break;
            }
        }

    }
}
