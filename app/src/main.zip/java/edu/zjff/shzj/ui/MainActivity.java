package edu.zjff.shzj.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;

import edu.zjff.shzj.R;
import edu.zjff.shzj.util.PermissionUtils;
import edu.zjff.shzj.util.ToastUtils;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    ImageView iv_login,iv_regist;
    PermissionUtils permissionUtils = new PermissionUtils(MainActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_login=findViewById(R.id.iv_login);iv_regist=findViewById(R.id.iv_regist);
        permissionUtils.request();
        iv_login.setOnClickListener(this);
        iv_regist.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
            switch (v.getId()){
                case R.id.iv_login:

                    break;
                case R.id.iv_regist:
                    Intent intent = new Intent(MainActivity.this,Activity_regist.class);
                    startActivity(intent);
                    break;
            }
    }





    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            if(requestCode==permissionUtils.PERMISSION){
                if (EasyPermissions.hasPermissions(MainActivity.this,  permissionUtils.PERMS)) {
                    ToastUtils.showToast(MainActivity.this,"授权成功",0);
                } else {
                    ToastUtils.showToast(MainActivity.this,"授权失败",0);
                }
            }
    }

}
