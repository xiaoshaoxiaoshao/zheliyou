package edu.zjff.shzj.util;

public interface Constant {
     String BROADCAST_REG_SUCCESS = "BROADCAST_REG_SUCCESS";
     String BROADCAST_REG_WRONG = "BROADCAST_REG_WRONG";
     String REGIST_URL = "http://shzj-server.pwnhub.net:8997/android/register";
     String YZM_URL = "http://shzj-server.pwnhub.net:8997//captcha/captchaImage?type=char";

    String USER = "USER";

    String YZM = "YZM";
    String BROADCAST_YZM_WRONG = "BROADCAST_YZM_WRONG";

    String BROADCAST_YZM_SUCCESS = "BROADCAST_YZM_SUCCESS";
}
